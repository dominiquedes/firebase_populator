# firebase_populator/__init__.py

"""
firebase_populator: A package to populate Firebase Firestore with generated data.
"""

__version__ = '0.1.0'  # Package version

from .firebase_populator import FirebasePopulator